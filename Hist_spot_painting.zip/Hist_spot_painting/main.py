import colorgram
import turtle
from turtle import Turtle, Screen
import random
turtle.colormode(255)
tim = Turtle()
tim.hideturtle()
tim.shape("arrow")
tim.color("black")
tim.setheading(135)
tim.penup()
tim.forward(80)
tim.right(135)


colors = colorgram.extract('image.jpg', 78)
for i in range(0,10):
    for j in range(0,10):
        tim.dot(10, colors[j].rgb)
        tim.penup()
        tim.forward(30)
    if (i % 2 == 0 and i!=9):
        tim.right(90)
        tim.forward(30)
        tim.right(90)
        tim.forward(30)
        tim.dot(10, 'blue')
    elif(i % 2 !=0 and i!=9):
            tim.left(90)
            tim.forward(30)
            tim.left(90)
            tim.forward(30)
            tim.dot(10, 'blue')


screen = Screen()
screen.exitonclick()