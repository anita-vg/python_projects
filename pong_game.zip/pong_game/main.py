import time
from turtle import Screen
from paddle import Paddle
from ball import Ball
from scoreboard import ScoreBoard
import time

POSITIONS = [(380,0),(-380,0)]

screen = Screen()
screen.setup(width=800, height=600)
screen.bgcolor("black")
screen.title("Pong Game")
screen.tracer(0)
left_paddle = Paddle(POSITIONS[1])
right_paddle = Paddle(POSITIONS[0])
scoreboard = ScoreBoard()
ball = Ball()
screen.listen()

screen.onkey(right_paddle.move_up,"Up")
screen.onkey(right_paddle.move_down,"Down")
screen.onkey(left_paddle.move_up,"w")
screen.onkey(left_paddle.move_down,"s")

game_is_on = True
while game_is_on:
    screen.update()
    time.sleep(ball.move_speed)
    ball.ball_move()
    if ball.ycor() > 280 or ball.ycor() < -280:
        ball.ball_bounce_y()

    if ball.xcor() > 360 and ball.distance(right_paddle) < 50 or ball.xcor() < -360 and ball.distance(left_paddle) < 50:
        ball.ball_bounce_x()

    if ball.xcor() > 380:
        scoreboard.left_score_increase()
        ball.reset_position()

    if ball.xcor() < -380:
        scoreboard.right_score_increase()
        ball.reset_position()

screen.exitonclick()

