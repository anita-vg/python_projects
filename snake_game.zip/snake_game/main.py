from turtle import  Screen
from snake import Snake
from food import Food
from scoreboard import ScoreBoard
import time
screen = Screen()
screen.setup(width=800,height=500)
screen.bgcolor("black")
screen.title("Snake Game")
screen.tracer(0)

snake = Snake()
food = Food()
scoreboard = ScoreBoard()
screen.listen()
screen.onkey(snake.move_up,"Up")
screen.onkey(snake.move_down,"Down")
screen.onkey(snake.move_right,"Right")
screen.onkey(snake.move_left,"Left")

Game_is_on = True

while Game_is_on:
    screen.update()
    time.sleep(0.1)
    snake.move()
    #Detect collision
    if snake.segment[0].distance(food) < 15:
        food.refresh()
        snake.extend_snake()
        scoreboard.update_score()

    #Detect wall collision
    if snake.segment[0].xcor() > 390 or snake.segment[0].xcor() <- 390 or snake.segment[0].ycor() > 240 or snake.segment[0].ycor() < -230:
        Game_is_on = False
        scoreboard.game_over()

    #Detect collision with tail
    for segment in snake.segment[1:]:
        if snake.segment[0].distance(segment) < 10:
            Game_is_on = False
            scoreboard.game_over()


screen.exitonclick()