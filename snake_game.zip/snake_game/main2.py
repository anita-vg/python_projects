class Animal:
    def __init__(self):
        self.num_of_eyes = 2

    def breathe(self):
        print("All animals breathe")

class Fish(Animal):
    def __init__(self):
        super().__init__()
    def breathe(self):

        print("Fish breathe under water")
        super().breathe()
    def swim(self):
        print("Move in water")

nemo = Fish()
nemo.breathe()