from turtle import Turtle
UP = 90
DOWN = 270
RIGHT = 0
LEFT = 180

STARTING_POSITIONS = [(0,0),(-20,0),(-40,0)]
class Snake:
    def __init__(self):
        self.segment = []
        self.create_snake()
    def create_snake(self):
        for position  in STARTING_POSITIONS:
            self.add_segment(position)

    def move(self):
                for seg_num in range(len(self.segment) - 1, 0, -1):
                    old_pos = self.segment[seg_num - 1].position()
                    self.segment[seg_num].setposition(old_pos)
                self.segment[0].forward(20)

    def move_up(self):
        if self.segment[0].heading() != DOWN:
            self.segment[0].setheading(UP)
    def move_down(self):
        if self.segment[0].heading() != UP:
            self.segment[0].setheading(DOWN)
    def move_right(self):
        if self.segment[0].heading() != LEFT:
            self.segment[0].setheading(RIGHT)
    def move_left(self):
        if self.segment[0].heading() != RIGHT:
            self.segment[0].setheading(LEFT)

    def add_segment(self,position):
        new_segment = Turtle(shape="square")
        new_segment.color("white")
        new_segment.penup()
        new_segment.goto(position)
        self.segment.append(new_segment)

    def extend_snake(self):
        self.add_segment(self.segment[-1].position())





