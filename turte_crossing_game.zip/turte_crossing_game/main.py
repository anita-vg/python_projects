from turtle import Screen
from scoreboard import ScoreBoard
from player import Player
from cars import Cars
import time

screen = Screen()
screen.setup(width=600,height=600)
screen.bgcolor("white")
screen.title("Turtle Crossing Game")
screen.listen()
screen.tracer(0)
scoreboard = ScoreBoard()
player = Player()
car = Cars()

game_is_on = True

screen.onkey(player.move_turtle,key="Up")

while game_is_on:
    time.sleep(0.1)
    screen.update()
    car.create_car()
    car.move_car()

    for each_car in car.all_cars:
        if each_car.distance(player) < 20:
            game_is_on = False
            scoreboard.game_over()

    if player.is_at_finish_line():
        player.go_to_start()
        car.level_up()
        scoreboard.update_score()


screen.exitonclick()
