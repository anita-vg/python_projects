from turtle import Turtle

class ScoreBoard(Turtle):
    def __init__(self):
        super().__init__()
        self.score = 0
        self.penup()
        self.hideturtle()
        self.goto(-230,270)
        self.color("black")
        self.print_score()

    def print_score(self):
        self.clear()
        self.write(f"Level = {self.score}", align="center", font=("Arial", 20, "normal"))

    def update_score(self):
        self.score += 1
        self.print_score()

    def game_over(self):
        self.goto(0,0)
        self.write("GAME OVER", align="center", font=("Arial",40,"normal"))


